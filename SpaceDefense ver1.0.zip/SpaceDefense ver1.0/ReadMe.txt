Introduction
	- This is a game developed by a student of "University of Applied Sciences Europe".
	- The game is made by Artem Gulyaev, Geumseong Han and Lenny Steve Jox.
	- The aim of the game is to destroy all the enemies and survive as many waves as possible.
	- Run “SpaceDefense.exe” to play the game

How to Pay
	- Shoot the incoming objects
	- Buy turrents and place them at already set locations
	- Survive as many waves as possible